from __future__ import annotations

from pathlib import Path
from urllib.request import urlopen
import json
import math

import numpy as np


def require_pandas():
    try:
        import pandas as pd
    except ImportError as exc:
        raise RuntimeError("pandas is required for dataset adapters.") from exc
    return pd


def download_file(url: str, path: Path, *, overwrite: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        return
    with urlopen(url, timeout=120) as response:
        data = response.read()
    path.write_bytes(data)


def write_metadata(path: Path, metadata: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")


def find_column(columns, candidates: list[str], *, required: bool = True) -> str | None:
    normalized = {normalize_name(c): c for c in columns}
    for cand in candidates:
        key = normalize_name(cand)
        if key in normalized:
            return normalized[key]
    if required:
        raise ValueError(f"Could not find any of {candidates} in columns {list(columns)}")
    return None


def normalize_name(name: str) -> str:
    return "".join(ch.lower() for ch in str(name).strip() if ch.isalnum())


def parse_timestamp(series):
    pd = require_pandas()
    return pd.to_datetime(series, errors="coerce")


def aggregate_duplicate_timestamps(df, *, time_col: str = "timestamp"):
    numeric_cols = [c for c in df.columns if c != time_col and np.issubdtype(df[c].dtype, np.number)]
    return df.groupby(time_col, as_index=False)[numeric_cols].mean()


def resample_timeseries(df, *, interval_min: int | None, time_col: str = "timestamp"):
    if interval_min is None:
        return df.sort_values(time_col).reset_index(drop=True)
    pd = require_pandas()
    df = df.sort_values(time_col).set_index(time_col)
    numeric_cols = [c for c in df.columns if np.issubdtype(df[c].dtype, np.number)]
    out = df[numeric_cols].resample(f"{interval_min}min").mean()
    out = out.dropna(how="all").reset_index()
    out[time_col] = pd.to_datetime(out[time_col])
    return out


def add_clear_sky_proxy(df, *, time_col: str = "timestamp", latitude_deg: float = 32.88):
    """Add simple timestamp-derived irradiance proxy when measured weather is absent.

    This is not a substitute for real meteorological data. It is intended to
    provide a reproducible diurnal/seasonal physical prior when the microgrid
    dataset does not include irradiance.
    """
    pd = require_pandas()
    df = df.copy()
    ts = pd.to_datetime(df[time_col])
    day_of_year = ts.dt.dayofyear.to_numpy()
    hour = ts.dt.hour.to_numpy() + ts.dt.minute.to_numpy() / 60.0
    latitude = math.radians(latitude_deg)
    decl = np.deg2rad(23.44) * np.sin(2 * np.pi * (day_of_year - 81) / 365.0)
    hour_angle = np.deg2rad(15.0 * (hour - 12.0))
    sin_elev = np.sin(latitude) * np.sin(decl) + np.cos(latitude) * np.cos(decl) * np.cos(hour_angle)
    clear = 1000.0 * np.clip(sin_elev, 0.0, None)
    df["clear_sky_poa"] = clear
    if "poa" not in df.columns:
        if "power_kw" in df.columns and df["power_kw"].max() > 0:
            scaled = df["power_kw"].to_numpy(dtype=float) / max(float(df["power_kw"].quantile(0.99)), 1e-6)
            df["poa"] = np.clip(clear * np.maximum(scaled, 0.0), 0.0, clear)
        else:
            df["poa"] = clear
    if "ghi" not in df.columns:
        df["ghi"] = df["poa"]
    if "dni" not in df.columns:
        df["dni"] = 0.75 * df["ghi"]
    if "dhi" not in df.columns:
        df["dhi"] = 0.25 * df["ghi"]
    if "temp_air" not in df.columns:
        df["temp_air"] = 25.0
    return df


def finalize_output(df, *, output_csv: Path, metadata: dict, interval_min: int | None):
    df = df.copy()
    df = df.sort_values("timestamp")
    if interval_min is not None:
        df = resample_timeseries(df, interval_min=interval_min)
    df = df.dropna(subset=["timestamp", "power_kw"])
    df["power_kw"] = df["power_kw"].clip(lower=0.0)
    if "load_kw" in df.columns:
        df["load_kw"] = df["load_kw"].clip(lower=0.0)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_csv, index=False)
    metadata = dict(metadata)
    metadata.update(
        {
            "rows": int(len(df)),
            "start": str(df["timestamp"].min()) if len(df) else None,
            "end": str(df["timestamp"].max()) if len(df) else None,
            "columns": list(df.columns),
            "estimated_capacity_kw_p99": float(df["power_kw"].quantile(0.99)) if len(df) else None,
            "estimated_capacity_kw_max": float(df["power_kw"].max()) if len(df) else None,
        }
    )
    write_metadata(output_csv.with_suffix(".metadata.json"), metadata)
    return df
