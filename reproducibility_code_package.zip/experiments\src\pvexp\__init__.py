"""Experiment utilities for physics-guided PV forecasting."""
