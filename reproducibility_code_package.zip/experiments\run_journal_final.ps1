$ErrorActionPreference = "Stop"

$Python = ".\.venv\Scripts\python.exe"

& $Python experiments/run_experiments.py `
  --data-csv data/processed/bath_pv_bess_microgrid.csv `
  --capacity-kw 3.2 `
  --interval-min 1 `
  --window 24 `
  --horizons 1,6,12 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer `
  --seeds 1,2,3,4,5 `
  --epochs 40 `
  --out-dir experiments/results/bath_final

& $Python experiments/run_experiments.py `
  --data-csv data/processed/storenet_community.csv `
  --capacity-kw 9.6 `
  --interval-min 5 `
  --window 48 `
  --horizons 1,6,12 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer `
  --seeds 1,2,3,4,5 `
  --epochs 40 `
  --out-dir experiments/results/storenet_final

& $Python experiments/run_experiments.py `
  --data-csv data/processed/ucsd_microgrid.csv `
  --capacity-kw 1766.597 `
  --interval-min 15 `
  --window 48 `
  --horizons 1,6,12 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer `
  --seeds 1,2,3,4,5 `
  --epochs 40 `
  --out-dir experiments/results/ucsd_final

& $Python experiments/evaluate_ensemble.py --results-dir experiments/results/bath_final --capacity-kw 3.2 --conformal
& $Python experiments/evaluate_ensemble.py --results-dir experiments/results/storenet_final --capacity-kw 9.6 --conformal
& $Python experiments/evaluate_ensemble.py --results-dir experiments/results/ucsd_final --capacity-kw 1766.597 --conformal
