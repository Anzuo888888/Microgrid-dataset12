$ErrorActionPreference = "Stop"

$Python = ".\.venv\Scripts\python.exe"

& $Python experiments/adapters/convert_ucsd.py `
  --download `
  --raw-dir data/raw/ucsd `
  --output-csv data/processed/ucsd_microgrid.csv `
  --interval-min 15

& $Python experiments/adapters/convert_storenet.py `
  --download `
  --households H5_W,H8_W,H18_W,H7_W `
  --raw-dir data/raw/storenet `
  --output-csv data/processed/storenet_community.csv `
  --interval-min 5

& $Python experiments/adapters/convert_bath.py `
  --download `
  --raw-csv data/raw/bath/Hyrbid_Microgrid_Data.csv `
  --output-csv data/processed/bath_pv_bess_microgrid.csv `
  --interval-min 1 `
  --start "2020-01-01 00:00:00"

& $Python experiments/run_experiments.py `
  --data-csv data/processed/bath_pv_bess_microgrid.csv `
  --capacity-kw 3.2 `
  --interval-min 1 `
  --window 24 `
  --horizons 1,6,12 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer,gated_bounded_transformer `
  --seeds 1,2 `
  --epochs 10 `
  --out-dir experiments/results/bath_fast

& $Python experiments/run_experiments.py `
  --data-csv data/processed/storenet_community.csv `
  --capacity-kw 9.6 `
  --interval-min 5 `
  --window 48 `
  --horizons 1,6,12 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer,gated_bounded_transformer `
  --seeds 1,2 `
  --epochs 3 `
  --train-fractions 0.1 `
  --out-dir experiments/results/storenet_fast

& $Python experiments/run_experiments.py `
  --data-csv data/processed/ucsd_microgrid.csv `
  --capacity-kw 1766.597 `
  --interval-min 15 `
  --window 48 `
  --horizons 1,6,12 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer,gated_bounded_transformer `
  --seeds 1,2 `
  --epochs 3 `
  --train-fractions 0.1 `
  --out-dir experiments/results/ucsd_fast

& $Python experiments/evaluate_ensemble.py --results-dir experiments/results/bath_fast --capacity-kw 3.2 --conformal
& $Python experiments/evaluate_ensemble.py --results-dir experiments/results/storenet_fast --capacity-kw 9.6 --conformal
& $Python experiments/evaluate_ensemble.py --results-dir experiments/results/ucsd_fast --capacity-kw 1766.597 --conformal
