from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class DatasetConfig:
    csv_path: Path
    capacity_kw: float
    interval_min: int
    timestamp_col: str = "timestamp"
    power_col: str = "power_kw"


@dataclass
class WindowData:
    x_train: np.ndarray
    y_train: np.ndarray
    meta_train: dict[str, np.ndarray]
    x_val: np.ndarray
    y_val: np.ndarray
    meta_val: dict[str, np.ndarray]
    x_test: np.ndarray
    y_test: np.ndarray
    meta_test: dict[str, np.ndarray]
    feature_names: list[str]


def _require_pandas():
    try:
        import pandas as pd
    except ImportError as exc:
        raise RuntimeError(
            "pandas is required for CSV loading. Install experiments/requirements.txt "
            "or use the bundled Codex Python runtime if it has pandas."
        ) from exc
    return pd


def load_pv_csv(cfg: DatasetConfig):
    pd = _require_pandas()
    df = pd.read_csv(cfg.csv_path)
    if cfg.timestamp_col not in df.columns:
        raise ValueError(f"Missing timestamp column: {cfg.timestamp_col}")
    if cfg.power_col not in df.columns:
        raise ValueError(f"Missing power column: {cfg.power_col}")
    df[cfg.timestamp_col] = pd.to_datetime(df[cfg.timestamp_col])
    df = df.sort_values(cfg.timestamp_col).reset_index(drop=True)
    df = df.rename(columns={cfg.power_col: "power_kw"})
    numeric_cols = [c for c in df.columns if c != cfg.timestamp_col and np.issubdtype(df[c].dtype, np.number)]
    if numeric_cols:
        df[numeric_cols] = df[numeric_cols].replace([np.inf, -np.inf], np.nan)
        df[numeric_cols] = df[numeric_cols].interpolate(limit_direction="both")
    return df


def generate_synthetic_pv(
    *,
    days: int,
    interval_min: int,
    capacity_kw: float,
    seed: int,
):
    pd = _require_pandas()
    rng = np.random.default_rng(seed)
    n = int(days * 24 * 60 / interval_min)
    t = np.arange(n)
    timestamp = pd.date_range("2024-01-01", periods=n, freq=f"{interval_min}min")

    steps_per_day = int(24 * 60 / interval_min)
    hour = (t % steps_per_day) * interval_min / 60.0
    day = t / steps_per_day
    season = 0.75 + 0.25 * np.sin(2 * np.pi * day / 365.0 + 0.3)
    solar_shape = np.maximum(0.0, np.sin(np.pi * (hour - 6.0) / 12.0))
    cloud = 0.75 + 0.25 * np.sin(2 * np.pi * day / 7.0 + 0.8)
    cloud += rng.normal(0, 0.08, size=n)
    cloud = np.clip(cloud, 0.15, 1.05)

    ghi = 980.0 * season * solar_shape * cloud
    dni = 0.75 * ghi + rng.normal(0, 25, size=n)
    dhi = 0.25 * ghi + rng.normal(0, 15, size=n)
    temp_air = 18 + 10 * np.sin(2 * np.pi * (hour - 8) / 24.0) + 5 * season
    clear_sky_poa = 1000.0 * season * solar_shape
    poa = np.clip(0.9 * ghi + 0.1 * dni + rng.normal(0, 20, size=n), 0, None)

    temp_cell = temp_air + (45 - 20) / 800.0 * poa
    ref = capacity_kw * 0.90 * (poa / 1000.0) * (1 - 0.004 * (temp_cell - 25))
    ref = np.clip(ref, 0, capacity_kw)
    noise = rng.normal(0, 0.035 * capacity_kw, size=n) * (solar_shape > 0)
    power_kw = np.clip(ref + noise, 0, capacity_kw)

    return pd.DataFrame(
        {
            "timestamp": timestamp,
            "power_kw": power_kw,
            "ghi": np.clip(ghi, 0, None),
            "dni": np.clip(dni, 0, None),
            "dhi": np.clip(dhi, 0, None),
            "temp_air": temp_air,
            "poa": poa,
            "clear_sky_poa": clear_sky_poa,
        }
    )


def build_windows(
    df,
    *,
    window: int,
    horizon: int,
    target_col: str,
    capacity_kw: float,
    train_fraction: float = 1.0,
    split_mode: str = "chronological",
    test_months: list[int] | None = None,
) -> WindowData:
    feature_names = [
        c
        for c in df.columns
        if c not in {"timestamp", target_col}
        and np.issubdtype(df[c].dtype, np.number)
    ]
    if target_col not in df.columns:
        raise ValueError(f"Missing target column: {target_col}")
    if "pmax_kw" not in df.columns:
        raise ValueError("Physics features must be added before windowing.")

    values = df[feature_names].to_numpy(dtype=float)
    target = df[target_col].to_numpy(dtype=float)
    pmax = df["pmax_kw"].to_numpy(dtype=float)
    pref = df["pref_kw"].to_numpy(dtype=float)

    timestamps = df["timestamp"].to_numpy() if "timestamp" in df.columns else None
    xs, ys, pmaxs, prefs, target_times = [], [], [], [], []
    for i in range(window, len(df) - horizon + 1):
        xs.append(values[i - window : i])
        ys.append(target[i : i + horizon])
        pmaxs.append(pmax[i : i + horizon])
        prefs.append(pref[i : i + horizon])
        if timestamps is not None:
            target_times.append(timestamps[i + horizon - 1])

    x = np.asarray(xs, dtype=float)
    y = np.asarray(ys, dtype=float)
    pmax_arr = np.asarray(pmaxs, dtype=float)
    pref_arr = np.asarray(prefs, dtype=float)

    n = len(x)
    if split_mode == "chronological":
        n_train_full = int(n * 0.60)
        n_train = max(1, int(n_train_full * train_fraction))
        n_val = int(n * 0.20)
        train_idx = np.arange(n_train_full - n_train, n_train_full)
        val_idx = np.arange(n_train_full, n_train_full + n_val)
        test_idx = np.arange(n_train_full + n_val, n)
    elif split_mode == "seasonal":
        if timestamps is None:
            raise ValueError("Seasonal split requires a timestamp column.")
        if not test_months:
            raise ValueError("Seasonal split requires --test-months, e.g. 12,1,2.")
        pd = _require_pandas()
        target_month = pd.to_datetime(np.asarray(target_times)).month.to_numpy()
        test_mask = np.isin(target_month, np.asarray(test_months))
        candidate_train = np.flatnonzero(~test_mask)
        if len(candidate_train) < 10 or test_mask.sum() < 10:
            raise ValueError("Seasonal split produced too few train or test samples.")
        n_val = max(1, int(len(candidate_train) * 0.20))
        train_full = candidate_train[:-n_val]
        val_idx = candidate_train[-n_val:]
        n_train = max(1, int(len(train_full) * train_fraction))
        train_idx = train_full[-n_train:]
        test_idx = np.flatnonzero(test_mask)
    else:
        raise ValueError(f"Unknown split_mode: {split_mode}")

    scaler_mean = x[train_idx].reshape(-1, x.shape[-1]).mean(axis=0)
    scaler_std = x[train_idx].reshape(-1, x.shape[-1]).std(axis=0)
    scaler_std = np.where(scaler_std < 1e-8, 1.0, scaler_std)

    x_scaled = (x - scaler_mean) / scaler_std

    last_power_all = df[target_col].to_numpy(dtype=float)[window - 1 : len(df) - horizon]
    last_pref_all = df["pref_kw"].to_numpy(dtype=float)[window - 1 : len(df) - horizon]

    def meta(idx):
        return {
            "pmax": pmax_arr[idx],
            "pref": pref_arr[idx],
            "last_power": last_power_all[idx],
            "last_pref": last_pref_all[idx],
        }

    return WindowData(
        x_train=x_scaled[train_idx],
        y_train=y[train_idx],
        meta_train=meta(train_idx),
        x_val=x_scaled[val_idx],
        y_val=y[val_idx],
        meta_val=meta(val_idx),
        x_test=x_scaled[test_idx],
        y_test=y[test_idx],
        meta_test=meta(test_idx),
        feature_names=feature_names,
    )
