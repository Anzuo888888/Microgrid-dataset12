$ErrorActionPreference = "Stop"

$Python = ".\.venv\Scripts\python.exe"

& $Python experiments/run_experiments.py `
  --data-csv data/processed/storenet_community.csv `
  --capacity-kw 9.6 `
  --interval-min 5 `
  --window 48 `
  --horizons 1,6,12 `
  --models svr,lstm,cnn_lstm `
  --seeds 1,2 `
  --epochs 3 `
  --train-fractions 0.1 `
  --out-dir experiments/results/storenet_missing_baselines

& $Python experiments/run_experiments.py `
  --data-csv data/processed/ucsd_microgrid.csv `
  --capacity-kw 1766.597 `
  --interval-min 15 `
  --window 48 `
  --horizons 1,6,12 `
  --models svr,lstm,cnn_lstm `
  --seeds 1,2 `
  --epochs 3 `
  --train-fractions 0.1 `
  --out-dir experiments/results/ucsd_missing_baselines
