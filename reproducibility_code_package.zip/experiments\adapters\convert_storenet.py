from __future__ import annotations

import argparse
from pathlib import Path
import json
from urllib.request import urlopen

from common import (
    add_clear_sky_proxy,
    finalize_output,
    find_column,
    parse_timestamp,
    require_pandas,
    download_file,
)


FIGSHARE_COLLECTION_ARTICLES = "https://api.figshare.com/v2/collections/6829134/articles"
FIGSHARE_ARTICLE = "https://api.figshare.com/v2/articles/{article_id}"


def fetch_figshare_articles():
    # The collection is small enough that the default API page returns the data
    # files needed by this adapter.
    with urlopen(FIGSHARE_COLLECTION_ARTICLES, timeout=120) as response:
        return json.loads(response.read().decode("utf-8"))


def download_storenet(raw_dir: Path, *, households: list[str], include_weather: bool, overwrite: bool = False) -> None:
    wanted = set(households)
    if include_weather:
        wanted.add("Weather data")
    articles = fetch_figshare_articles()
    for item in articles:
        title = item["title"]
        if title not in wanted:
            continue
        with urlopen(FIGSHARE_ARTICLE.format(article_id=item["id"]), timeout=120) as response:
            article = json.loads(response.read().decode("utf-8"))
        for file_info in article.get("files", []):
            target = raw_dir / file_info["name"]
            print(f"Downloading {title}: {file_info['download_url']} -> {target}")
            download_file(file_info["download_url"], target, overwrite=overwrite)


def convert_storenet(
    raw_dir: Path,
    output_csv: Path,
    *,
    interval_min: int,
    households: list[str],
    use_soltot_as_ghi: bool,
):
    pd = require_pandas()
    frames = []
    for household in households:
        path = raw_dir / f"{household}.csv"
        if not path.exists():
            raise FileNotFoundError(f"Missing StoreNet household file: {path}")
        df = pd.read_csv(path)
        time_col = find_column(df.columns, ["date"])
        prod_col = find_column(df.columns, ["Production(W)", "Production"])
        cons_col = find_column(df.columns, ["Consumption(W)", "Consumption"])
        charge_col = find_column(df.columns, ["Charge(W)", "Charge"], required=False)
        discharge_col = find_column(df.columns, ["Discharge(W)", "Discharge"], required=False)
        soc_col = find_column(df.columns, ["State of Charge(%)", "State of Charge", "SOC"], required=False)
        frame = pd.DataFrame(
            {
                "timestamp": parse_timestamp(df[time_col]),
                f"power_kw_{household}": pd.to_numeric(df[prod_col], errors="coerce") / 1000.0,
                f"load_kw_{household}": pd.to_numeric(df[cons_col], errors="coerce") / 1000.0,
            }
        )
        if charge_col:
            frame[f"battery_charge_kw_{household}"] = pd.to_numeric(df[charge_col], errors="coerce") / 1000.0
        if discharge_col:
            frame[f"battery_discharge_kw_{household}"] = pd.to_numeric(df[discharge_col], errors="coerce") / 1000.0
        if soc_col:
            frame[f"soc_{household}"] = pd.to_numeric(df[soc_col], errors="coerce")
        frames.append(frame)

    merged = None
    for frame in frames:
        merged = frame if merged is None else merged.merge(frame, on="timestamp", how="outer")
    power_cols = [c for c in merged.columns if c.startswith("power_kw_")]
    load_cols = [c for c in merged.columns if c.startswith("load_kw_")]
    charge_cols = [c for c in merged.columns if c.startswith("battery_charge_kw_")]
    discharge_cols = [c for c in merged.columns if c.startswith("battery_discharge_kw_")]
    soc_cols = [c for c in merged.columns if c.startswith("soc_")]
    out = pd.DataFrame({"timestamp": merged["timestamp"]})
    out["power_kw"] = merged[power_cols].sum(axis=1, min_count=1)
    out["pmax_kw"] = 2.4 * len(households)
    out["load_kw"] = merged[load_cols].sum(axis=1, min_count=1)
    if charge_cols:
        out["battery_charge_kw"] = merged[charge_cols].sum(axis=1, min_count=1)
    if discharge_cols:
        out["battery_discharge_kw"] = merged[discharge_cols].sum(axis=1, min_count=1)
    if charge_cols or discharge_cols:
        charge = out["battery_charge_kw"] if "battery_charge_kw" in out else 0.0
        discharge = out["battery_discharge_kw"] if "battery_discharge_kw" in out else 0.0
        out["battery_kw"] = discharge - charge
    if soc_cols:
        out["soc"] = merged[soc_cols].mean(axis=1)

    weather_path = raw_dir / "weather.csv"
    if weather_path.exists():
        weather = pd.read_csv(weather_path, low_memory=False)
        time_col = find_column(weather.columns, ["date"])
        weather_out = pd.DataFrame({"timestamp": parse_timestamp(weather[time_col])})
        sol_col = find_column(weather.columns, ["soltot"], required=False)
        temp_col = find_column(weather.columns, ["drybulb"], required=False)
        wind_col = find_column(weather.columns, ["speed"], required=False)
        rain_col = find_column(weather.columns, ["rain"], required=False)
        if sol_col:
            weather_out["weather_solar"] = pd.to_numeric(weather[sol_col], errors="coerce")
            if use_soltot_as_ghi:
                weather_out["ghi"] = weather_out["weather_solar"].clip(lower=0.0)
                weather_out["poa"] = weather_out["ghi"]
                weather_out["clear_sky_poa"] = weather_out["ghi"].rolling(1440, min_periods=1).max()
        if temp_col:
            weather_out["temp_air"] = pd.to_numeric(weather[temp_col], errors="coerce")
        if wind_col:
            weather_out["wind_speed"] = pd.to_numeric(weather[wind_col], errors="coerce")
        if rain_col:
            weather_out["rain"] = pd.to_numeric(weather[rain_col], errors="coerce")
        out = out.merge(weather_out, on="timestamp", how="left")
        out = out.sort_values("timestamp")
        weather_cols = [c for c in weather_out.columns if c != "timestamp"]
        out[weather_cols] = out[weather_cols].interpolate(limit_direction="both")

    if "ghi" not in out.columns:
        out = add_clear_sky_proxy(out, latitude_deg=52.14)

    if "ghi" in out.columns:
        out["ghi"] = out["ghi"].clip(lower=0.0)
        if "poa" in out.columns:
            out["poa"] = out["poa"].clip(lower=0.0)
        out["dni"] = 0.75 * out["ghi"].clip(lower=0.0)
        out["dhi"] = 0.25 * out["ghi"].clip(lower=0.0)

    metadata = {
        "dataset": "StoreNet / Ireland Energy Community",
        "source": "https://doi.org/10.6084/m9.figshare.c.6829134",
        "microgrid_framing": "energy community used as a community microgrid proxy",
        "households": households,
        "notes": [
            "Power, load, charge, and discharge are converted from W to kW.",
            "power_kw is aggregate PV Production(W).",
            "battery_kw is discharge minus charge.",
            "Weather soltot is retained as weather_solar. By default, timestamp-derived clear_sky_poa/poa/ghi are used because soltot is not assumed to be standard W/m^2 irradiance.",
            "If --use-soltot-as-ghi is passed, soltot is mapped to ghi/poa and dni/dhi are simple derived proxies.",
            "pmax_kw is set to 2.4 kW times the number of selected PV households, based on the StoreNet README.",
        ],
    }
    finalize_output(out, output_csv=output_csv, metadata=metadata, interval_min=interval_min)


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert StoreNet figshare files to unified PV experiment CSV.")
    parser.add_argument("--raw-dir", type=Path, default=Path("data/raw/storenet"))
    parser.add_argument("--output-csv", type=Path, default=Path("data/processed/storenet_community.csv"))
    parser.add_argument("--interval-min", type=int, default=5)
    parser.add_argument("--households", default="H5_W,H8_W,H18_W,H7_W")
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--no-weather", action="store_true")
    parser.add_argument("--use-soltot-as-ghi", action="store_true")
    args = parser.parse_args()
    households = [h.strip() for h in args.households.split(",") if h.strip()]
    if args.download:
        download_storenet(args.raw_dir, households=households, include_weather=not args.no_weather, overwrite=args.overwrite)
    convert_storenet(
        args.raw_dir,
        args.output_csv,
        interval_min=args.interval_min,
        households=households,
        use_soltot_as_ghi=args.use_soltot_as_ghi,
    )
    print(f"Wrote {args.output_csv}")


if __name__ == "__main__":
    main()
