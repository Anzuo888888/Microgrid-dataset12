from __future__ import annotations

import argparse
from pathlib import Path
import sys
from urllib.request import urlopen
import json

from common import (
    add_clear_sky_proxy,
    aggregate_duplicate_timestamps,
    download_file,
    finalize_output,
    find_column,
    parse_timestamp,
    require_pandas,
)


GITHUB_API = "https://api.github.com/repos/sushilsilwal3/UCSD-Microgrid-Database/contents"
RAW_BASE = "https://raw.githubusercontent.com/sushilsilwal3/UCSD-Microgrid-Database/master"

UCSD_PV_FILES = [
    "BSB_BuildingPV.csv",
    "BSB_LibraryPV.csv",
    "BioEngineeringPV.csv",
    "CSC_BuildingPV.csv",
    "CUP_PV.csv",
    "EBU2_A_PV.csv",
    "EBU2_B_PV.csv",
    "ElectricShopPV.csv",
    "GarageFleetsPV.csv",
    "GilmanParkingPV.csv",
    "HopkinsParkingPV.csv",
    "KeelingA_PV.csv",
    "KeelingB_PV.csv",
    "KyoceraSkylinePV.csv",
    "LeichtagPV.csv",
    "MESOM_PV.csv",
    "MayerHallPV.csv",
    "OslerParkingPV.csv",
    "PowellPV.csv",
    "PriceCenterA_PV.csv",
    "PriceCenterB_PV.csv",
    "SDSC_PV.csv",
    "SME_SolarPV.csv",
    "StephenBirchPV.csv",
]

UCSD_BUILDING_LOAD_FILES = [
    "CenterHall.csv",
    "EastCampus.csv",
    "GalbraithHall.csv",
    "GeiselLibrary.csv",
    "Mandeville.csv",
    "MusicBuilding.csv",
    "OttersonHall.csv",
    "PepperCanyon.csv",
    "RadyHall.csv",
    "RobinsonHall.csv",
    "SocialScience.csv",
    "StudentServices.csv",
]


def list_github_dir(path: str):
    with urlopen(f"{GITHUB_API}/{path}?ref=master", timeout=120) as response:
        return json.loads(response.read().decode("utf-8"))


def download_ucsd(
    raw_dir: Path,
    *,
    overwrite: bool = False,
    max_pv_files: int | None = None,
    include_building_load: bool = False,
) -> None:
    targets = []
    try:
        pv_items = list_github_dir("Data%20Files/PVGenerator")
    except Exception:
        pv_items = [
            {
                "name": name,
                "download_url": f"{RAW_BASE}/Data%20Files/PVGenerator/{name}",
            }
            for name in UCSD_PV_FILES
        ]
    for item in pv_items:
        if item["name"].endswith(".csv"):
            targets.append((item["download_url"], raw_dir / "Data Files" / "PVGenerator" / item["name"]))
    if max_pv_files is not None:
        targets = targets[:max_pv_files]
    if include_building_load:
        try:
            load_items = list_github_dir("Data%20Files/BuildingLoad")
        except Exception:
            load_items = [
                {
                    "name": name,
                    "download_url": f"{RAW_BASE}/Data%20Files/BuildingLoad/{name}",
                }
                for name in UCSD_BUILDING_LOAD_FILES
            ]
        for item in load_items:
            if item["name"].endswith(".csv"):
                targets.append((item["download_url"], raw_dir / "Data Files" / "BuildingLoad" / item["name"]))
    for name in ["BatteryStorage.csv", "DemandCharge.csv"]:
        targets.append((f"{RAW_BASE}/Data%20Files/{name}", raw_dir / "Data Files" / name))
    for url, path in targets:
        print(f"Downloading {url} -> {path}")
        download_file(url, path, overwrite=overwrite)


def read_real_power_csv(path: Path, *, value_name: str, clip_negative: bool = False):
    pd = require_pandas()
    df = pd.read_csv(path, encoding="utf-8-sig")
    time_col = find_column(df.columns, ["DateTime", "timestamp", "date"])
    value_col = find_column(df.columns, ["RealPower", value_name])
    out = pd.DataFrame(
        {
            "timestamp": parse_timestamp(df[time_col]),
            value_name: pd.to_numeric(df[value_col], errors="coerce"),
        }
    )
    if clip_negative:
        out[value_name] = out[value_name].clip(lower=0.0)
    return aggregate_duplicate_timestamps(out.dropna(subset=["timestamp"]))


def sum_timeseries(frames, *, value_name: str):
    pd = require_pandas()
    if not frames:
        raise ValueError(f"No frames to aggregate for {value_name}")
    merged = None
    for i, frame in enumerate(frames):
        frame = frame.rename(columns={value_name: f"{value_name}_{i}"})
        merged = frame if merged is None else merged.merge(frame, on="timestamp", how="outer")
    value_cols = [c for c in merged.columns if c.startswith(f"{value_name}_")]
    merged[value_name] = merged[value_cols].sum(axis=1, min_count=1)
    return merged[["timestamp", value_name]]


def convert_ucsd(raw_dir: Path, output_csv: Path, *, interval_min: int, use_demand_charge: bool, add_proxy: bool):
    pd = require_pandas()
    data_dir = raw_dir / "Data Files"
    pv_dir = data_dir / "PVGenerator"
    if not pv_dir.exists():
        raise FileNotFoundError(f"Missing UCSD PV directory: {pv_dir}")

    pv_frames = [
        read_real_power_csv(path, value_name="power_kw", clip_negative=True)
        for path in sorted(pv_dir.glob("*.csv"))
    ]
    pv = sum_timeseries(pv_frames, value_name="power_kw")

    demand_file = data_dir / "DemandCharge.csv"
    if use_demand_charge and demand_file.exists():
        df = pd.read_csv(demand_file, encoding="utf-8-sig")
        time_col = find_column(df.columns, ["DateTime"])
        load_col = find_column(df.columns, ["TotalCampusLoad"])
        load = pd.DataFrame(
            {
                "timestamp": parse_timestamp(df[time_col]),
                "load_kw": pd.to_numeric(df[load_col], errors="coerce"),
            }
        )
        load = aggregate_duplicate_timestamps(load.dropna(subset=["timestamp"]))
    else:
        load_dir = data_dir / "BuildingLoad"
        load_frames = [
            read_real_power_csv(path, value_name="load_kw", clip_negative=True)
            for path in sorted(load_dir.glob("*.csv"))
        ]
        load = sum_timeseries(load_frames, value_name="load_kw")

    out = pv.merge(load, on="timestamp", how="outer")
    ucsd_capacity_proxy = float(out["power_kw"].quantile(0.999)) if "power_kw" in out else None
    if ucsd_capacity_proxy and ucsd_capacity_proxy > 0:
        out["pmax_kw"] = ucsd_capacity_proxy

    battery_file = data_dir / "BatteryStorage.csv"
    if battery_file.exists():
        battery = read_real_power_csv(battery_file, value_name="battery_kw", clip_negative=False)
        battery["battery_discharge_kw"] = battery["battery_kw"].clip(lower=0.0)
        battery["battery_charge_kw"] = (-battery["battery_kw"]).clip(lower=0.0)
        out = out.merge(battery, on="timestamp", how="outer")

    out = out.sort_values("timestamp")
    if add_proxy:
        out = add_clear_sky_proxy(out, latitude_deg=32.88)

    metadata = {
        "dataset": "UCSD Microgrid Database",
        "source": "https://github.com/sushilsilwal3/UCSD-Microgrid-Database",
        "microgrid_framing": "real campus microgrid",
        "notes": [
            "PV power is the aggregate of Data Files/PVGenerator/*.csv.",
            "Load is TotalCampusLoad from DemandCharge.csv when available.",
            "BatteryStorage RealPower is retained as signed battery_kw; positive values are treated as discharge for derived columns.",
            "Weather is not included in the UCSD files; clear_sky_poa/poa/ghi are timestamp-derived proxies if --no-clear-sky-proxy is not used.",
            "pmax_kw is a constant aggregate capacity proxy estimated from the 99.9th percentile of aggregate PV power because measured irradiance is not available.",
        ],
    }
    finalize_output(out, output_csv=output_csv, metadata=metadata, interval_min=interval_min)


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert UCSD Microgrid Database files to unified PV experiment CSV.")
    parser.add_argument("--raw-dir", type=Path, default=Path("data/raw/ucsd"))
    parser.add_argument("--output-csv", type=Path, default=Path("data/processed/ucsd_microgrid.csv"))
    parser.add_argument("--interval-min", type=int, default=15)
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--max-pv-files", type=int, default=None, help="Optional smaller UCSD download for quick tests.")
    parser.add_argument("--aggregate-building-load", action="store_true", help="Use BuildingLoad/*.csv instead of DemandCharge TotalCampusLoad.")
    parser.add_argument("--no-clear-sky-proxy", action="store_true")
    args = parser.parse_args()

    if args.download:
        download_ucsd(
            args.raw_dir,
            overwrite=args.overwrite,
            max_pv_files=args.max_pv_files,
            include_building_load=args.aggregate_building_load,
        )
    convert_ucsd(
        args.raw_dir,
        args.output_csv,
        interval_min=args.interval_min,
        use_demand_charge=not args.aggregate_building_load,
        add_proxy=not args.no_clear_sky_proxy,
    )
    print(f"Wrote {args.output_csv}")


if __name__ == "__main__":
    main()
