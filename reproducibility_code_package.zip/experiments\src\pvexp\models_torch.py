from __future__ import annotations

import math
import random
import copy

import numpy as np


class TorchSequenceModel:
    def __init__(
        self,
        *,
        name: str,
        seed: int,
        capacity_kw: float,
        epochs: int = 40,
        batch_size: int = 64,
        learning_rate: float = 1e-3,
    ):
        try:
            import torch
            import torch.nn as nn
        except ImportError as exc:
            raise RuntimeError(
                f"Model {name} requires torch. Install experiments/requirements.txt."
            ) from exc
        self.torch = torch
        self.nn = nn
        self.name = name
        self.seed = seed
        self.capacity_kw = capacity_kw
        self.model = None
        self.epochs = epochs
        self.batch_size = batch_size
        self.lr = learning_rate
        self.anchor_weights_: np.ndarray | None = None

    def fit(self, windows):
        torch = self.torch
        nn = self.nn
        self._seed_everything()
        input_dim = windows.x_train.shape[-1]
        if self.name == "lstm":
            self.model = _LSTMRegressor(input_dim=input_dim)
        elif self.name == "cnn_lstm":
            self.model = _CNNLSTMRegressor(input_dim=input_dim)
        elif self.name in {"transformer", "transformer_clip"}:
            self.model = _TransformerRegressor(input_dim=input_dim)
        elif self.name in {"bounded_transformer", "gated_bounded_transformer"}:
            self.model = _BoundedTransformerRegressor(input_dim=input_dim)
        else:
            raise ValueError(self.name)

        x_train = torch.tensor(windows.x_train, dtype=torch.float32)
        y_train = torch.tensor(windows.y_train[:, -1], dtype=torch.float32)
        pref_train = torch.tensor(windows.meta_train["pref"][:, -1], dtype=torch.float32)
        pmax_train = torch.tensor(windows.meta_train["pmax"][:, -1], dtype=torch.float32)
        last_train = torch.tensor(windows.meta_train["last_power"], dtype=torch.float32)
        last_pref_train = torch.tensor(windows.meta_train["last_pref"], dtype=torch.float32)
        x_val = torch.tensor(windows.x_val, dtype=torch.float32)
        y_val = torch.tensor(windows.y_val[:, -1], dtype=torch.float32)
        pref_val = torch.tensor(windows.meta_val["pref"][:, -1], dtype=torch.float32)
        pmax_val = torch.tensor(windows.meta_val["pmax"][:, -1], dtype=torch.float32)
        last_val = torch.tensor(windows.meta_val["last_power"], dtype=torch.float32)
        last_pref_val = torch.tensor(windows.meta_val["last_pref"], dtype=torch.float32)

        opt = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        loss_fn = nn.MSELoss()
        best_state = None
        best_val = math.inf
        patience = 8
        stale = 0
        for _epoch in range(self.epochs):
            self.model.train()
            order = torch.randperm(len(x_train))
            for start in range(0, len(order), self.batch_size):
                idx = order[start : start + self.batch_size]
                pred = self._forward(
                    x_train[idx],
                    pref_train[idx],
                    pmax_train[idx],
                    last_train[idx],
                    last_pref_train[idx],
                )
                loss = loss_fn(pred, y_train[idx])
                opt.zero_grad()
                loss.backward()
                opt.step()
            self.model.eval()
            with torch.no_grad():
                val_pred = self._forward(x_val, pref_val, pmax_val, last_val, last_pref_val)
                val_loss = float(loss_fn(val_pred, y_val).item())
            if val_loss < best_val:
                best_val = val_loss
                best_state = copy.deepcopy(self.model.state_dict())
                stale = 0
            else:
                stale += 1
                if stale >= patience:
                    break
        if best_state is not None:
            self.model.load_state_dict(best_state)
        if self.name == "gated_bounded_transformer":
            self.model.eval()
            with torch.no_grad():
                base_val = self.model(x_val, pref_val, pmax_val).cpu().numpy()
            self.anchor_weights_ = self._fit_anchor_weights(
                anchors=self._numpy_anchor_matrix(
                    last_power=windows.meta_val["last_power"],
                    pref=windows.meta_val["pref"][:, -1],
                    pmax=windows.meta_val["pmax"][:, -1],
                    last_pref=windows.meta_val["last_pref"],
                    bounded=base_val,
                ),
                bounded=base_val,
                target=windows.y_val[:, -1],
            )
        return self

    def predict(self, x, meta):
        torch = self.torch
        if self.model is None:
            raise RuntimeError("Model must be fitted before prediction.")
        self.model.eval()
        with torch.no_grad():
            x_t = torch.tensor(x, dtype=torch.float32)
            pref = torch.tensor(meta["pref"][:, -1], dtype=torch.float32)
            pmax = torch.tensor(meta["pmax"][:, -1], dtype=torch.float32)
            last_power = torch.tensor(meta["last_power"], dtype=torch.float32)
            last_pref = torch.tensor(meta["last_pref"], dtype=torch.float32)
            pred = self._forward(x_t, pref, pmax, last_power, last_pref).cpu().numpy()
        return pred

    def _forward(self, x, pref, pmax, last_power=None, last_pref=None):
        if self.name == "bounded_transformer":
            return self.model(x, pref, pmax)
        if self.name == "gated_bounded_transformer":
            base = self.model(x, pref, pmax)
            if self.anchor_weights_ is None:
                return base
            weights = self.torch.tensor(self.anchor_weights_, dtype=base.dtype, device=base.device)
            anchors = self._torch_anchor_matrix(
                last_power=last_power,
                pref=pref,
                pmax=pmax,
                last_pref=last_pref,
                bounded=base,
            )
            pred = (weights[:, None] * anchors).sum(dim=0)
            return self.torch.minimum(self.torch.clamp(pred, min=0.0), pmax)
        pred = self.model(x)
        if self.name == "transformer_clip":
            pred = self.torch.minimum(self.torch.clamp(pred, min=0.0), pmax)
        return pred

    @staticmethod
    def _fit_anchor_weights(*, anchors, bounded, target):
        anchors = [np.asarray(anchor, dtype=float) for anchor in anchors]
        target = np.asarray(target, dtype=float)
        bounded_idx = 2
        best_weights = np.eye(len(anchors))[bounded_idx]
        best_mse = float(np.mean((np.asarray(bounded, dtype=float) - target) ** 2))
        # First allow a pure anchor. This is important for short horizons, where
        # persistence corrected by physical trend can be the statistically best
        # forecast and should not be diluted by the neural component.
        for idx, anchor in enumerate(anchors):
            mse = float(np.mean((anchor - target) ** 2))
            if mse < best_mse:
                best_mse = mse
                best_weights = np.eye(len(anchors))[idx]
        # Then search pairwise convex blends. This is much less prone to
        # validation overfitting than a full high-dimensional simplex grid.
        grid = np.linspace(0.0, 1.0, 101)
        for i in range(len(anchors)):
            for j in range(i + 1, len(anchors)):
                for w_i in grid:
                    pred = w_i * anchors[i] + (1.0 - w_i) * anchors[j]
                    mse = float(np.mean((pred - target) ** 2))
                    if mse < best_mse:
                        best_mse = mse
                        best_weights = np.zeros(len(anchors), dtype=float)
                        best_weights[i] = w_i
                        best_weights[j] = 1.0 - w_i
        return best_weights

    @staticmethod
    def _numpy_anchor_matrix(*, last_power, pref, pmax, last_pref, bounded):
        last_power = np.asarray(last_power, dtype=float)
        pref = np.asarray(pref, dtype=float)
        pmax = np.asarray(pmax, dtype=float)
        last_pref = np.asarray(last_pref, dtype=float)
        bounded = np.asarray(bounded, dtype=float)
        persistence = np.minimum(np.maximum(last_power, 0.0), pmax)
        physics = np.minimum(np.maximum(pref, 0.0), pmax)
        physics_delta = np.minimum(np.maximum(last_power + (pref - last_pref), 0.0), pmax)
        physics_ratio = np.minimum(np.maximum(last_power * pref / (last_pref + 1e-6), 0.0), pmax)
        return [persistence, physics, bounded, physics_delta, physics_ratio]

    def _torch_anchor_matrix(self, *, last_power, pref, pmax, last_pref, bounded):
        torch = self.torch
        persistence = torch.minimum(torch.clamp(last_power, min=0.0), pmax)
        physics = torch.minimum(torch.clamp(pref, min=0.0), pmax)
        physics_delta = torch.minimum(torch.clamp(last_power + (pref - last_pref), min=0.0), pmax)
        physics_ratio = torch.minimum(torch.clamp(last_power * pref / (last_pref + 1e-6), min=0.0), pmax)
        return torch.stack([persistence, physics, bounded, physics_delta, physics_ratio], dim=0)

    def _seed_everything(self):
        random.seed(self.seed)
        np.random.seed(self.seed)
        self.torch.manual_seed(self.seed)


def _activation():
    import torch.nn as nn

    return nn.GELU()


def _make_head(hidden_dim: int):
    import torch.nn as nn

    return nn.Sequential(nn.Linear(hidden_dim, hidden_dim), _activation(), nn.Linear(hidden_dim, 1))


class _LSTMRegressor:
    def __init__(self, input_dim: int, hidden_dim: int = 64):
        import torch.nn as nn

        self.module = nn.Module()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.head = _make_head(hidden_dim)

    def __call__(self, x):
        _, (h, _) = self.lstm(x)
        return self.head(h[-1]).squeeze(-1)

    def train(self):
        self.lstm.train()
        self.head.train()

    def eval(self):
        self.lstm.eval()
        self.head.eval()

    def parameters(self):
        return list(self.lstm.parameters()) + list(self.head.parameters())

    def state_dict(self):
        return {"lstm": self.lstm.state_dict(), "head": self.head.state_dict()}

    def load_state_dict(self, state):
        self.lstm.load_state_dict(state["lstm"])
        self.head.load_state_dict(state["head"])


class _CNNLSTMRegressor(_LSTMRegressor):
    def __init__(self, input_dim: int, hidden_dim: int = 64):
        import torch.nn as nn

        self.conv = nn.Conv1d(input_dim, input_dim, kernel_size=3, padding=1)
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.head = _make_head(hidden_dim)

    def __call__(self, x):
        z = self.conv(x.transpose(1, 2)).transpose(1, 2)
        _, (h, _) = self.lstm(z)
        return self.head(h[-1]).squeeze(-1)

    def train(self):
        self.conv.train()
        self.lstm.train()
        self.head.train()

    def eval(self):
        self.conv.eval()
        self.lstm.eval()
        self.head.eval()

    def parameters(self):
        return list(self.conv.parameters()) + list(self.lstm.parameters()) + list(self.head.parameters())

    def state_dict(self):
        return {"conv": self.conv.state_dict(), "lstm": self.lstm.state_dict(), "head": self.head.state_dict()}

    def load_state_dict(self, state):
        self.conv.load_state_dict(state["conv"])
        self.lstm.load_state_dict(state["lstm"])
        self.head.load_state_dict(state["head"])


class _TransformerRegressor(_LSTMRegressor):
    def __init__(self, input_dim: int, hidden_dim: int = 64, nhead: int = 4, layers: int = 2):
        import torch
        import torch.nn as nn

        self.proj = nn.Linear(input_dim, hidden_dim)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=nhead,
            dim_feedforward=hidden_dim * 4,
            dropout=0.1,
            batch_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=layers)
        self.head = _make_head(hidden_dim)
        self.registered_pos = torch.zeros(1)

    def __call__(self, x):
        z = self.proj(x)
        z = self.encoder(z)
        return self.head(z[:, -1]).squeeze(-1)

    def train(self):
        self.proj.train()
        self.encoder.train()
        self.head.train()

    def eval(self):
        self.proj.eval()
        self.encoder.eval()
        self.head.eval()

    def parameters(self):
        return list(self.proj.parameters()) + list(self.encoder.parameters()) + list(self.head.parameters())

    def state_dict(self):
        return {"proj": self.proj.state_dict(), "encoder": self.encoder.state_dict(), "head": self.head.state_dict()}

    def load_state_dict(self, state):
        self.proj.load_state_dict(state["proj"])
        self.encoder.load_state_dict(state["encoder"])
        self.head.load_state_dict(state["head"])


class _BoundedTransformerRegressor(_TransformerRegressor):
    def __call__(self, x, pref, pmax):
        import torch

        delta = super().__call__(x)
        q_ref = torch.clamp(pref / (pmax + 1e-6), 1e-4, 1 - 1e-4)
        q_hat = torch.sigmoid(torch.logit(q_ref) + delta)
        return torch.minimum(torch.clamp(pmax * q_hat, min=0.0), pmax)
