from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from pvexp.metrics import deterministic_metrics, physical_violation_metrics
from pvexp.reporting import write_metrics, write_summary


PATTERN = re.compile(r"pred_(?P<model>.+)_h(?P<horizon>\d+)_s(?P<seed>\d+)_tf(?P<tf>[0-9.]+)\.npz$")


def main() -> None:
    parser = argparse.ArgumentParser(description="Recompute deterministic metrics from saved pred_*.npz files.")
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--capacity-kw", type=float, required=True)
    args = parser.parse_args()

    rows = []
    for path in sorted(args.results_dir.glob("pred_*.npz")):
        match = PATTERN.match(path.name)
        if not match:
            continue
        arr = np.load(path)
        pred = arr["pred"]
        target = arr["target"]
        pmax = arr["pmax"]
        row = deterministic_metrics(target, pred, args.capacity_kw)
        row.update(physical_violation_metrics(pred, pmax))
        row.update(
            {
                "model": match.group("model"),
                "seed": int(match.group("seed")),
                "horizon": int(match.group("horizon")),
                "train_fraction": float(match.group("tf")),
            }
        )
        rows.append(row)

    write_metrics(rows, args.results_dir / "metrics.csv")
    write_summary(rows, args.results_dir / "summary.csv")
    print(f"Recovered {len(rows)} metric rows from {args.results_dir}")


if __name__ == "__main__":
    main()
