from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


DATASETS = [
    ("Bath", "bath_fast"),
    ("Bath", "bath_gated_full"),
    ("StoreNet", "storenet_fast"),
    ("StoreNet", "storenet_gated_full"),
    ("UCSD", "ucsd_fast"),
    ("UCSD", "ucsd_gated_full"),
]


MODEL_ORDER = [
    "persistence",
    "svr",
    "random_forest",
    "lstm",
    "cnn_lstm",
    "transformer",
    "transformer_clip",
    "bounded_transformer",
    "gated_bounded_transformer",
]

DATASET_ORDER = {name: idx for idx, (name, _) in enumerate(DATASETS)}


def fmt_mean_std(mean, std) -> str:
    if pd.isna(mean):
        return ""
    if pd.isna(std) or float(std) == 0.0:
        return f"{float(mean):.4f}"
    return f"{float(mean):.4f} $\\pm$ {float(std):.4f}"


def read_deterministic(results_root: Path) -> pd.DataFrame:
    frames = []
    for dataset, directory in DATASETS:
        path = results_root / directory / "summary.csv"
        if not path.exists():
            continue
        df = pd.read_csv(path)
        df.insert(0, "dataset", dataset)
        df.insert(1, "result_dir", directory)
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def read_ensemble(results_root: Path) -> pd.DataFrame:
    frames = []
    for dataset, directory in DATASETS:
        path = results_root / directory / "ensemble_metrics_conformal.csv"
        if not path.exists():
            continue
        df = pd.read_csv(path)
        df.insert(0, "dataset", dataset)
        df.insert(1, "result_dir", directory)
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def write_nrmse_table(df: pd.DataFrame, out_path: Path) -> None:
    rows = []
    for (dataset, horizon), group in df.groupby(["dataset", "horizon"], sort=False):
        row = {"Dataset": dataset, "Horizon": int(horizon)}
        by_model = group.set_index("model")
        for model in MODEL_ORDER:
            if model not in by_model.index:
                row[model] = ""
                continue
            item = by_model.loc[model]
            row[model] = fmt_mean_std(item["nrmse_mean"], item["nrmse_std"])
        rows.append(row)
    table = pd.DataFrame(rows)
    table["dataset_order"] = table["Dataset"].map(DATASET_ORDER)
    table = table.sort_values(["dataset_order", "Horizon"]).drop(columns=["dataset_order"])
    table.to_latex(out_path, index=False, escape=False)


def write_violation_table(df: pd.DataFrame, out_path: Path) -> None:
    keep = {
        "svr",
        "random_forest",
        "lstm",
        "cnn_lstm",
        "transformer",
        "transformer_clip",
        "bounded_transformer",
        "gated_bounded_transformer",
    }
    cols = [
        "dataset",
        "horizon",
        "model",
        "negative_violation_pct_mean",
        "over_capacity_violation_pct_mean",
    ]
    table = df[df["model"].isin(keep)][cols].copy()
    table = table.sort_values(["dataset", "horizon", "model"])
    table["negative_violation_pct_mean"] = table["negative_violation_pct_mean"].map(lambda x: f"{x:.3f}")
    table["over_capacity_violation_pct_mean"] = table["over_capacity_violation_pct_mean"].map(lambda x: f"{x:.3f}")
    table = table.rename(
        columns={
            "dataset": "Dataset",
            "horizon": "Horizon",
            "model": "Model",
            "negative_violation_pct_mean": "Neg. violation (%)",
            "over_capacity_violation_pct_mean": "Over-capacity violation (%)",
        }
    )
    table.to_latex(out_path, index=False, escape=False)


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate journal experiment outputs.")
    parser.add_argument("--results-root", type=Path, default=Path(__file__).resolve().parent / "results")
    parser.add_argument("--prefix", default="fast")
    args = parser.parse_args()

    args.results_root.mkdir(parents=True, exist_ok=True)
    deterministic = read_deterministic(args.results_root)
    ensemble = read_ensemble(args.results_root)

    if deterministic.empty:
        raise SystemExit("No summary.csv files found.")

    det_out = args.results_root / f"{args.prefix}_deterministic_summary.csv"
    deterministic.to_csv(det_out, index=False)
    write_nrmse_table(deterministic, args.results_root / f"{args.prefix}_nrmse_table.tex")
    write_violation_table(deterministic, args.results_root / f"{args.prefix}_violation_table.tex")

    if not ensemble.empty:
        ensemble.to_csv(args.results_root / f"{args.prefix}_ensemble_conformal_summary.csv", index=False)

    print(f"Wrote {det_out}")


if __name__ == "__main__":
    main()
