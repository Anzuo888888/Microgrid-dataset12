from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from pvexp.metrics import crps_ensemble, deterministic_metrics, interval_metrics, physical_violation_metrics
from pvexp.reporting import write_metrics


PATTERN = re.compile(r"pred_(?P<model>.+)_h(?P<horizon>\d+)_s(?P<seed>\d+)_tf(?P<tf>[0-9.]+)\.npz$")


def conformal_interval(val_samples, val_target, test_samples, test_pmax, alpha):
    val_lower = np.quantile(val_samples, alpha / 2, axis=0)
    val_upper = np.quantile(val_samples, 1 - alpha / 2, axis=0)
    scores = np.maximum(val_lower - val_target, val_target - val_upper)
    scores = np.maximum(scores, 0.0)
    q = min(1.0, np.ceil((len(scores) + 1) * (1 - alpha)) / len(scores))
    try:
        c_alpha = np.quantile(scores, q, method="higher")
    except TypeError:
        c_alpha = np.quantile(scores, q, interpolation="higher")
    test_lower = np.quantile(test_samples, alpha / 2, axis=0)
    test_upper = np.quantile(test_samples, 1 - alpha / 2, axis=0)
    return (
        np.clip(test_lower - c_alpha, 0.0, test_pmax),
        np.clip(test_upper + c_alpha, 0.0, test_pmax),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate ensemble forecasts saved by run_experiments.py.")
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--capacity-kw", type=float, required=True)
    parser.add_argument("--alpha", type=float, default=0.10)
    parser.add_argument("--conformal", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    groups = {}
    for path in args.results_dir.glob("pred_*.npz"):
        match = PATTERN.match(path.name)
        if not match:
            continue
        key = (match.group("model"), int(match.group("horizon")), float(match.group("tf")))
        groups.setdefault(key, []).append(path)

    rows = []
    for (model, horizon, train_fraction), paths in sorted(groups.items()):
        if len(paths) < 2:
            continue
        test_samples, val_samples = [], []
        target = pmax = val_target = val_pmax = None
        for path in paths:
            arr = np.load(path)
            test_samples.append(arr["pred"])
            val_samples.append(arr["pred_val"])
            target = arr["target"]
            pmax = arr["pmax"]
            val_target = arr["target_val"]
            val_pmax = arr["pmax_val"]

        test_samples = np.asarray(test_samples)
        val_samples = np.asarray(val_samples)
        mean_pred = test_samples.mean(axis=0)
        lower = np.quantile(test_samples, args.alpha / 2, axis=0)
        upper = np.quantile(test_samples, 1 - args.alpha / 2, axis=0)
        lower = np.clip(lower, 0.0, pmax)
        upper = np.clip(upper, 0.0, pmax)
        if args.conformal:
            lower, upper = conformal_interval(
                val_samples=val_samples,
                val_target=val_target,
                test_samples=test_samples,
                test_pmax=pmax,
                alpha=args.alpha,
            )

        row = {
            "model": model,
            "horizon": horizon,
            "train_fraction": train_fraction,
            "members": len(paths),
            "crps": crps_ensemble(test_samples, target),
        }
        row.update(deterministic_metrics(target, mean_pred, args.capacity_kw))
        row.update(interval_metrics(lower, upper, target, args.capacity_kw))
        row.update(physical_violation_metrics(mean_pred, pmax))
        rows.append(row)
        print(row)

    out = args.out or (args.results_dir / ("ensemble_metrics_conformal.csv" if args.conformal else "ensemble_metrics.csv"))
    write_metrics(rows, out)


if __name__ == "__main__":
    main()
