from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from pvexp.data import DatasetConfig, build_windows, generate_synthetic_pv, load_pv_csv
from pvexp.metrics import deterministic_metrics, physical_violation_metrics
from pvexp.models_numpy import (
    BoundedLinearResidual,
    PersistenceModel,
    PhysicalReferenceModel,
    SklearnModel,
)
from pvexp.physics import add_physics_features
from pvexp.reporting import write_metrics, write_summary


def parse_csv_list(value: str) -> list[str]:
    return [v.strip() for v in value.split(",") if v.strip()]


def parse_int_list(value: str) -> list[int]:
    return [int(v.strip()) for v in value.split(",") if v.strip()]


def make_model(name: str, seed: int, capacity_kw: float, *, epochs: int, batch_size: int, learning_rate: float):
    if name == "persistence":
        return PersistenceModel()
    if name == "physical_ref":
        return PhysicalReferenceModel()
    if name == "bounded_linear":
        return BoundedLinearResidual(alpha=1e-2, capacity_kw=capacity_kw)
    if name in {"svr", "random_forest"}:
        return SklearnModel(name=name, seed=seed)
    if name in {
        "lstm",
        "cnn_lstm",
        "transformer",
        "transformer_clip",
        "bounded_transformer",
        "gated_bounded_transformer",
    }:
        from pvexp.models_torch import TorchSequenceModel

        return TorchSequenceModel(
            name=name,
            seed=seed,
            capacity_kw=capacity_kw,
            epochs=epochs,
            batch_size=batch_size,
            learning_rate=learning_rate,
        )
    raise ValueError(f"Unknown model: {name}")


def run_one(
    *,
    data,
    model_name: str,
    seed: int,
    horizon: int,
    window: int,
    capacity_kw: float,
    train_fraction: float,
    split_mode: str,
    test_months: list[int] | None,
    epochs: int,
    batch_size: int,
    learning_rate: float,
):
    windows = build_windows(
        data,
        window=window,
        horizon=horizon,
        target_col="power_kw",
        capacity_kw=capacity_kw,
        train_fraction=train_fraction,
        split_mode=split_mode,
        test_months=test_months,
    )

    model = make_model(
        model_name,
        seed,
        capacity_kw,
        epochs=epochs,
        batch_size=batch_size,
        learning_rate=learning_rate,
    )
    model.fit(windows)
    pred = model.predict(windows.x_test, windows.meta_test)
    pred_val = model.predict(windows.x_val, windows.meta_val)
    target = windows.y_test[:, horizon - 1]
    target_val = windows.y_val[:, horizon - 1]
    pmax = windows.meta_test["pmax"][:, horizon - 1]
    pmax_val = windows.meta_val["pmax"][:, horizon - 1]

    metrics = deterministic_metrics(target, pred, capacity_kw)
    metrics.update(physical_violation_metrics(pred, pmax))
    metrics.update(
        {
            "model": model_name,
            "seed": seed,
            "horizon": horizon,
            "train_fraction": train_fraction,
        }
    )
    return metrics, pred, target, pmax, pred_val, target_val, pmax_val


def main() -> None:
    parser = argparse.ArgumentParser(description="Run PV forecasting experiments.")
    data_group = parser.add_mutually_exclusive_group(required=True)
    data_group.add_argument("--synthetic", action="store_true", help="Use synthetic PV-like data.")
    data_group.add_argument("--data-csv", type=Path, help="Path to real PV CSV.")
    parser.add_argument("--capacity-kw", type=float, default=500.0)
    parser.add_argument("--interval-min", type=int, default=5)
    parser.add_argument("--window", type=int, default=48)
    parser.add_argument("--horizons", type=parse_int_list, default=[1, 6, 12])
    parser.add_argument(
        "--models",
        type=parse_csv_list,
        default=["persistence", "physical_ref", "bounded_linear"],
    )
    parser.add_argument("--seeds", type=parse_int_list, default=[1])
    parser.add_argument("--train-fractions", type=parse_csv_list, default=["1.0"])
    parser.add_argument("--split-mode", choices=["chronological", "seasonal"], default="chronological")
    parser.add_argument(
        "--test-months",
        type=parse_int_list,
        default=None,
        help="Seasonal test months, e.g. 12,1,2. Used only with --split-mode seasonal.",
    )
    parser.add_argument("--out-dir", type=Path, default=ROOT / "results" / "default")
    parser.add_argument("--synthetic-days", type=int, default=120)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)

    if args.synthetic:
        data = generate_synthetic_pv(
            days=args.synthetic_days,
            interval_min=args.interval_min,
            capacity_kw=args.capacity_kw,
            seed=123,
        )
    else:
        cfg = DatasetConfig(
            csv_path=args.data_csv,
            capacity_kw=args.capacity_kw,
            interval_min=args.interval_min,
        )
        data = load_pv_csv(cfg)

    data = add_physics_features(data, capacity_kw=args.capacity_kw)

    all_metrics = []
    for train_fraction_text in args.train_fractions:
        train_fraction = float(train_fraction_text)
        for horizon in args.horizons:
            for model_name in args.models:
                for seed in args.seeds:
                    metrics, pred, target, pmax, pred_val, target_val, pmax_val = run_one(
                        data=data,
                        model_name=model_name,
                        seed=seed,
                        horizon=horizon,
                        window=args.window,
                        capacity_kw=args.capacity_kw,
                        train_fraction=train_fraction,
                        split_mode=args.split_mode,
                        test_months=args.test_months,
                        epochs=args.epochs,
                        batch_size=args.batch_size,
                        learning_rate=args.learning_rate,
                    )
                    all_metrics.append(metrics)
                    np.savez_compressed(
                        args.out_dir / f"pred_{model_name}_h{horizon}_s{seed}_tf{train_fraction}.npz",
                        pred=pred,
                        target=target,
                        pmax=pmax,
                        pred_val=pred_val,
                        target_val=target_val,
                        pmax_val=pmax_val,
                    )
                    write_metrics(all_metrics, args.out_dir / "metrics.csv")
                    write_summary(all_metrics, args.out_dir / "summary.csv")
                    print(json.dumps(metrics, indent=2))

    write_metrics(all_metrics, args.out_dir / "metrics.csv")
    write_summary(all_metrics, args.out_dir / "summary.csv")


if __name__ == "__main__":
    main()
