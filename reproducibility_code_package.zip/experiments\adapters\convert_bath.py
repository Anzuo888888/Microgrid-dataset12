from __future__ import annotations

import argparse
from pathlib import Path

from common import add_clear_sky_proxy, download_file, finalize_output, find_column, require_pandas


BATH_FILE_URL = "https://researchdata.bath.ac.uk/id/file/61170"


def convert_bath(raw_csv: Path, output_csv: Path, *, interval_min: int, start: str, add_proxy: bool):
    pd = require_pandas()
    df = pd.read_csv(raw_csv)
    pv_col = find_column(df.columns, ["PV input power"])
    load_col = find_column(df.columns, ["Output active power", "Total Output active power"], required=False)
    battery_col = find_column(df.columns, ["BatteryPower", "Battery Power"], required=False)
    battery_charge_col = find_column(df.columns, ["Battery Power (cha)", "Charging current"], required=False)
    soc_col = find_column(df.columns, ["Battery capacity"], required=False)

    timestamp = pd.date_range(start=start, periods=len(df), freq=f"{interval_min}min")
    out = pd.DataFrame(
        {
            "timestamp": timestamp,
            "power_kw": pd.to_numeric(df[pv_col], errors="coerce") / 1000.0,
        }
    )
    out["pmax_kw"] = 3.2
    if load_col:
        out["load_kw"] = pd.to_numeric(df[load_col], errors="coerce") / 1000.0
    if battery_col:
        out["battery_kw"] = pd.to_numeric(df[battery_col], errors="coerce") / 1000.0
    if battery_charge_col:
        # If the selected column is current rather than power, this is still a
        # useful auxiliary signal but should not be interpreted as kW in the paper.
        out["battery_charge_aux"] = pd.to_numeric(df[battery_charge_col], errors="coerce")
    if soc_col:
        out["soc"] = pd.to_numeric(df[soc_col], errors="coerce")

    if add_proxy:
        out = add_clear_sky_proxy(out, latitude_deg=51.38)

    metadata = {
        "dataset": "University of Bath PV-BESS Microgrid",
        "source": "https://researchdata.bath.ac.uk/1287/",
        "doi": "10.15125/BATH-01287",
        "microgrid_framing": "grid-tied PV-BESS microgrid",
        "notes": [
            "The Bath CSV does not include a timestamp column; timestamp is generated from --start and --interval-min.",
            "PV input power and output active power are converted from W to kW.",
            "Weather is not included; clear_sky_poa/poa/ghi are timestamp-derived proxies if --no-clear-sky-proxy is not used.",
            "pmax_kw is set to 3.2 kW based on the dataset description of the PV system.",
        ],
    }
    finalize_output(out, output_csv=output_csv, metadata=metadata, interval_min=None)


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert University of Bath PV-BESS microgrid data to unified CSV.")
    parser.add_argument("--raw-csv", type=Path, default=Path("data/raw/bath/Hyrbid Microgrid Data.csv"))
    parser.add_argument("--output-csv", type=Path, default=Path("data/processed/bath_pv_bess_microgrid.csv"))
    parser.add_argument("--interval-min", type=int, default=1)
    parser.add_argument("--start", default="2020-01-01 00:00:00")
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--no-clear-sky-proxy", action="store_true")
    args = parser.parse_args()
    if args.download:
        download_file(BATH_FILE_URL, args.raw_csv, overwrite=args.overwrite)
    convert_bath(
        args.raw_csv,
        args.output_csv,
        interval_min=args.interval_min,
        start=args.start,
        add_proxy=not args.no_clear_sky_proxy,
    )
    print(f"Wrote {args.output_csv}")


if __name__ == "__main__":
    main()
