from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "experiments" / "results" / "fast_deterministic_summary.csv"
FIG_DIR = ROOT / "figures"

MODEL_LABELS = {
    "persistence": "Persistence",
    "svr": "SVR",
    "random_forest": "RF",
    "lstm": "LSTM",
    "cnn_lstm": "CNN-LSTM",
    "transformer": "Transformer",
    "transformer_clip": "Trans.+clip",
    "bounded_transformer": "Bounded residual",
    "gated_bounded_transformer": "Gated bounded",
}

VIOLATION_MODELS = [
    "svr",
    "random_forest",
    "lstm",
    "cnn_lstm",
    "transformer",
    "transformer_clip",
    "bounded_transformer",
    "gated_bounded_transformer",
]

COLORS = {
    "persistence": "#6B7280",
    "svr": "#9C755F",
    "random_forest": "#59A14F",
    "lstm": "#B07AA1",
    "cnn_lstm": "#E15759",
    "transformer": "#4E79A7",
    "transformer_clip": "#F28E2B",
    "bounded_transformer": "#0F766E",
    "gated_bounded_transformer": "#7C3AED",
}


def plot_nrmse(df: pd.DataFrame) -> None:
    selected = df[df["model"].isin(MODEL_LABELS)].copy()
    datasets = ["Bath", "StoreNet", "UCSD"]
    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.4), sharey=False)

    for ax, dataset in zip(axes, datasets):
        part = selected[selected["dataset"] == dataset]
        for model in MODEL_LABELS:
            sub = part[part["model"] == model].sort_values("horizon")
            ax.errorbar(
                sub["horizon"],
                sub["nrmse_mean"],
                yerr=sub["nrmse_std"],
                marker="o",
                linewidth=1.8,
                capsize=3,
                label=MODEL_LABELS[model],
                color=COLORS[model],
            )
        ax.set_title(dataset)
        ax.set_xlabel("Forecast horizon (steps)")
        ax.set_xticks([1, 6, 12])
        ax.set_yscale("log")
        ax.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel("nRMSE (log scale)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4, frameon=False, fontsize=8)
    fig.tight_layout(rect=[0, 0, 1, 0.84])
    fig.savefig(FIG_DIR / "fig_nrmse_transformers.pdf", bbox_inches="tight")
    fig.savefig(FIG_DIR / "fig_nrmse_transformers.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def plot_violations(df: pd.DataFrame) -> None:
    selected = df[df["model"].isin(VIOLATION_MODELS)].copy()
    datasets = ["Bath", "StoreNet", "UCSD"]
    horizons = [1, 6, 12]
    bar_models = ["svr", "lstm", "cnn_lstm", "transformer"]

    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.45), sharey=True)
    x = np.arange(len(horizons))
    width = 0.18
    offsets = (np.arange(len(bar_models)) - (len(bar_models) - 1) / 2) * width

    for ax, dataset in zip(axes, datasets):
        part = selected[selected["dataset"] == dataset]
        for offset, model in zip(offsets, bar_models):
            values = []
            for horizon in horizons:
                mask = (part["horizon"] == horizon) & (part["model"] == model)
                values.append(float(part.loc[mask, "negative_violation_pct_mean"].iloc[0]))
            bars = ax.bar(
                x + offset,
                values,
                width=width * 0.92,
                color=COLORS[model],
                label=MODEL_LABELS[model],
                edgecolor="white",
                linewidth=0.6,
            )
            for bar, value in zip(bars, values):
                if value > 0:
                    label = "<0.1" if value < 0.1 else f"{value:.1f}"
                    ax.text(
                        bar.get_x() + bar.get_width() / 2,
                        value + 1.0,
                        label,
                        ha="center",
                        va="bottom",
                        fontsize=7,
                    )

        ax.scatter(
            x,
            np.zeros_like(x),
            marker="D",
            s=26,
            color="#111827",
            zorder=4,
            label="Zero violation",
        )
        ax.set_title(dataset)
        ax.set_xticks(x)
        ax.set_xticklabels([f"H{h}" for h in horizons])
        ax.set_xlabel("Forecast horizon")
        ax.set_ylim(0, 52)
        ax.grid(axis="y", alpha=0.25)

    axes[0].set_ylabel("Negative-output violation rate (%)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=5, frameon=False, fontsize=8)
    fig.tight_layout(rect=[0, 0, 1, 0.85])
    fig.savefig(FIG_DIR / "fig_physical_violations.pdf", bbox_inches="tight")
    fig.savefig(FIG_DIR / "fig_physical_violations.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RESULTS)
    plot_nrmse(df)
    plot_violations(df)
    print(f"Wrote figures to {FIG_DIR}")


if __name__ == "__main__":
    main()
