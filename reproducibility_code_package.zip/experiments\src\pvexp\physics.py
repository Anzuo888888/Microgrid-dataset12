from __future__ import annotations

import numpy as np


def add_physics_features(
    df,
    *,
    capacity_kw: float,
    noct: float = 45.0,
    derate: float = 0.90,
    temp_coeff: float = -0.004,
    g_stc: float = 1000.0,
):
    df = df.copy()
    if "poa" in df.columns:
        poa = df["poa"].to_numpy(dtype=float)
    elif {"ghi", "dni", "dhi"}.issubset(df.columns):
        poa = 0.9 * df["ghi"].to_numpy(dtype=float) + 0.1 * df["dni"].to_numpy(dtype=float)
    elif "ghi" in df.columns:
        poa = df["ghi"].to_numpy(dtype=float)
    else:
        raise ValueError("Need poa, ghi, or ghi/dni/dhi columns to compute PV physics features.")

    temp_air = (
        df["temp_air"].to_numpy(dtype=float)
        if "temp_air" in df.columns
        else np.full(len(df), 25.0)
    )
    clear_sky_poa = (
        df["clear_sky_poa"].to_numpy(dtype=float)
        if "clear_sky_poa" in df.columns
        else np.maximum.accumulate(np.maximum(poa, 0.0))
    )

    poa = np.clip(poa, 0.0, None)
    temp_cell = temp_air + (noct - 20.0) / 800.0 * poa
    if "pmax_kw" in df.columns:
        pmax = pd_to_numeric_array(df["pmax_kw"])
        pmax = np.clip(pmax, 0.0, capacity_kw)
        pmax = np.where(np.isfinite(pmax), pmax, capacity_kw)
    else:
        pmax = np.clip(capacity_kw * poa / g_stc, 0.0, capacity_kw)
    pref = capacity_kw * derate * (poa / g_stc) * (1.0 + temp_coeff * (temp_cell - 25.0))
    pref = np.clip(pref, 0.0, capacity_kw)

    eps = 1e-6
    df["poa_used"] = poa
    df["temp_cell"] = temp_cell
    df["pmax_kw"] = pmax
    df["pref_kw"] = pref
    df["clear_sky_index"] = poa / (np.clip(clear_sky_poa, 0.0, None) + eps)
    df["ref_ratio"] = pref / (pmax + eps)
    if "power_kw" in df.columns:
        df["performance_ratio"] = df["power_kw"].to_numpy(dtype=float) / (pref + eps)
    return df


def pd_to_numeric_array(series):
    try:
        import pandas as pd

        return pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
    except Exception:
        return np.asarray(series, dtype=float)
