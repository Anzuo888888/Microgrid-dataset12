from __future__ import annotations

import numpy as np


def deterministic_metrics(y_true: np.ndarray, y_pred: np.ndarray, capacity_kw: float) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_pred - y_true
    return {
        "nrmse": float(np.sqrt(np.mean(err**2)) / capacity_kw),
        "nmae": float(np.mean(np.abs(err)) / capacity_kw),
        "rmse_kw": float(np.sqrt(np.mean(err**2))),
        "mae_kw": float(np.mean(np.abs(err))),
    }


def physical_violation_metrics(y_pred: np.ndarray, pmax: np.ndarray, *, tol_kw: float = 1e-4) -> dict[str, float]:
    y_pred = np.asarray(y_pred, dtype=float)
    pmax = np.asarray(pmax, dtype=float)
    return {
        "negative_violation_pct": float(np.mean(y_pred < -tol_kw) * 100.0),
        "over_capacity_violation_pct": float(np.mean(y_pred - pmax > tol_kw) * 100.0),
    }


def crps_ensemble(samples: np.ndarray, y_true: np.ndarray) -> float:
    samples = np.asarray(samples, dtype=float)
    y_true = np.asarray(y_true, dtype=float)
    term1 = np.mean(np.abs(samples - y_true[None, :]), axis=0)
    pairwise = np.abs(samples[:, None, :] - samples[None, :, :])
    term2 = 0.5 * np.mean(pairwise, axis=(0, 1))
    return float(np.mean(term1 - term2))


def interval_metrics(lower: np.ndarray, upper: np.ndarray, y_true: np.ndarray, capacity_kw: float) -> dict[str, float]:
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    y_true = np.asarray(y_true, dtype=float)
    return {
        "picp": float(np.mean((lower <= y_true) & (y_true <= upper))),
        "pinaw": float(np.mean(upper - lower) / capacity_kw),
    }
