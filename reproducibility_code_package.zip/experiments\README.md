# PV Forecasting Experiment Suite

This folder contains a reproducible experiment scaffold for the revised journal
manuscript.

Public dataset candidates are summarized in
`experiments/public_dataset_candidates.md`.

## Current status

The repository now supports converted public microgrid/community datasets and
synthetic smoke tests. The scripts support two modes:

- `--synthetic`: generates a PV-like time series and runs smoke tests.
- `--data-csv`: runs experiments on a real CSV once SPDIS or another PV dataset
  is provided.

The local `.venv` has working `torch` and `scikit-learn` installations. Use
`.\.venv\Scripts\python.exe` on Windows if the shell does not activate the
environment automatically.

For computational tractability, the SVR and Random Forest baselines use at most
5,000 training windows by default when a converted dataset contains many more
samples. Report this subsampling rule in the final paper if these baselines are
included.

## Expected CSV schema

At minimum, provide:

- `timestamp`: parseable timestamp.
- `power_kw`: measured AC PV power.
- `ghi`: global horizontal irradiance.
- `dni`: direct normal irradiance.
- `dhi`: diffuse horizontal irradiance.
- `temp_air`: ambient temperature in Celsius.

Optional columns:

- `poa`: plane-of-array irradiance. If absent, the script uses a simple proxy
  from GHI/DNI/DHI.
- `clear_sky_poa`: clear-sky plane-of-array irradiance.

## Dataset adapters

The adapters convert public microgrid/community datasets into the CSV schema
above.

### UCSD Microgrid Database

Quick validation with two PV files:

```powershell
python experiments/adapters/convert_ucsd.py `
  --download `
  --max-pv-files 2 `
  --raw-dir data/raw/ucsd_sample `
  --output-csv data/processed/ucsd_microgrid_sample.csv `
  --interval-min 15
```

Full UCSD PV aggregate:

```powershell
python experiments/adapters/convert_ucsd.py `
  --download `
  --raw-dir data/raw/ucsd `
  --output-csv data/processed/ucsd_microgrid.csv `
  --interval-min 15
```

### StoreNet / Ireland Energy Community

Single-house quick validation:

```powershell
python experiments/adapters/convert_storenet.py `
  --download `
  --households H5_W `
  --raw-dir data/raw/storenet_sample `
  --output-csv data/processed/storenet_h5_sample.csv `
  --interval-min 5
```

Community aggregate using four households:

```powershell
python experiments/adapters/convert_storenet.py `
  --download `
  --households H5_W,H8_W,H18_W,H7_W `
  --raw-dir data/raw/storenet `
  --output-csv data/processed/storenet_community.csv `
  --interval-min 5
```

### University of Bath PV-BESS Microgrid

```powershell
python experiments/adapters/convert_bath.py `
  --download `
  --raw-csv data/raw/bath/Hyrbid_Microgrid_Data.csv `
  --output-csv data/processed/bath_pv_bess_microgrid.csv `
  --interval-min 1 `
  --start "2020-01-01 00:00:00"
```

Each adapter also writes a `*.metadata.json` file with source, framing, row
count, date range, output columns, and estimated PV capacity.

## Smoke test

```powershell
python experiments/run_experiments.py --synthetic --models persistence,physical_ref,bounded_linear --out-dir experiments/results/smoke
```

With the bundled Codex Python runtime:

```powershell
& "C:\Users\jiang\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" experiments/run_experiments.py --synthetic --models persistence,physical_ref,bounded_linear --out-dir experiments/results/smoke
```

## Real-data run

```powershell
python experiments/run_experiments.py `
  --data-csv data/case_a.csv `
  --capacity-kw 500 `
  --interval-min 5 `
  --models persistence,svr,random_forest,lstm,cnn_lstm,transformer,transformer_clip,bounded_transformer `
  --seeds 1,2,3,4,5 `
  --train-fractions 1.0 `
  --epochs 40 `
  --batch-size 64 `
  --out-dir experiments/results/case_a
```

Run Case B similarly with `--capacity-kw 1000 --interval-min 15`.

For data-scarcity experiments:

```powershell
python experiments/run_experiments.py `
  --data-csv data/case_a.csv `
  --capacity-kw 500 `
  --interval-min 5 `
  --models transformer,transformer_clip,bounded_transformer `
  --seeds 1,2,3,4,5 `
  --train-fractions 0.1,0.25,0.5,1.0 `
  --out-dir experiments/results/case_a_scarcity
```

For seasonal distribution-shift experiments:

```powershell
python experiments/run_experiments.py `
  --data-csv data/case_a.csv `
  --capacity-kw 500 `
  --interval-min 5 `
  --models transformer,transformer_clip,bounded_transformer `
  --seeds 1,2,3,4,5 `
  --split-mode seasonal `
  --test-months 12,1,2 `
  --out-dir experiments/results/case_a_winter_shift
```

For ensemble CRPS/PICP/PINAW:

```powershell
python experiments/evaluate_ensemble.py `
  --results-dir experiments/results/case_a `
  --capacity-kw 500 `
  --conformal
```

To aggregate the journal fast-run outputs into CSV and LaTeX tables:

```powershell
python experiments/aggregate_results.py --prefix fast
```

## Batch scripts

After creating `.venv` and installing `experiments/requirements.txt`, use:

```powershell
.\experiments\run_journal_fast.ps1
```

for a quick end-to-end run with fewer seeds/epochs, and:

```powershell
.\experiments\run_journal_final.ps1
```

for the longer journal table run.

## Outputs

- `metrics.csv`: one row per model, seed, and horizon.
- `summary.csv`: mean and standard deviation grouped by model and horizon.
- `pred_*.npz`: saved validation/test predictions for later ensemble scoring,
  plotting, and LaTeX tables.
- `ensemble_metrics.csv` or `ensemble_metrics_conformal.csv`: CRPS, PICP,
  PINAW, deterministic metrics of the ensemble mean, and physical violations.
- `fast_deterministic_summary.csv`: combined deterministic summary across
  Bath, StoreNet, and UCSD fast runs.
- `fast_ensemble_conformal_summary.csv`: combined deep-ensemble/conformal
  summary across the three fast-run datasets.
- `fast_nrmse_table.tex` and `fast_violation_table.tex`: LaTeX snippets for the
  main NRMSE table and physical-violation table.

## Journal submission checklist

Before submission, run:

- five random seeds for all neural models;
- Transformer plus post-hoc clipping;
- Transformer with bounded output;
- bounded residual Transformer;
- data scarcity settings: 10%, 25%, 50%, and 100% training data;
- seasonal shift splits;
- at least one probabilistic baseline besides deep ensemble, such as conformal
  quantile regression if implemented.
