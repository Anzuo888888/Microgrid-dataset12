# Public Dataset Candidates for the Revised PV/Microgrid Forecasting Paper

This document lists public datasets that are more defensible for a
microgrid-oriented PV forecasting paper than SPDIS-derived utility-scale PV
plants.

## Recommended Shortlist

### 1. UCSD Microgrid Database

- Source: https://github.com/sushilsilwal3/UCSD-Microgrid-Database
- Type: real campus microgrid.
- Signals: multi-year power generation, consumption, and storage data.
- Why it fits: this is the strongest candidate for proving microgrid relevance
  because UCSD operates a real campus microgrid and the repository is explicitly
  framed as a microgrid database.
- Use in paper: main real microgrid case study.
- Likely limitation: weather/irradiance may need to be added from another public
  source or approximated via clear-sky features from timestamp and location.

### 2. OpenCEM

- Source: https://tongxin.me/opencem/dataset.html
- Type: real campus energy system / microgrid-scale dataset.
- Signals: PV, battery, grid, load, context, air-conditioning, and occupancy
  related data at high temporal resolution.
- Why it fits: strong PV + BESS + campus energy context, useful for
  forecasting and distribution-shift experiments.
- Use in paper: second real campus case study or robustness case.
- Likely limitation: very new dataset; cite carefully and avoid relying on it as
  the only evidence if target journal prefers established datasets.

### 3. StoreNet / Ireland Energy Community Dataset

- Source: https://doi.org/10.6084/m9.figshare.c.6829134
- Paper: https://www.nature.com/articles/s41597-024-03454-2
- Type: real energy community with households, PV, batteries, EV charging, and
  weather.
- Signals: one-minute household electricity consumption, PV generation, battery
  operation, EV charging, and weather over a year.
- Why it fits: not a single islanded microgrid, but highly relevant to
  community microgrids, collective self-consumption, DER coordination, and
  distributed PV forecasting.
- Use in paper: community microgrid / distributed DER case study.
- Likely limitation: frame as an energy-community proxy, not as a traditional
  campus or island microgrid.

### 4. University of Bath Hybrid PV-Battery Microgrid Dataset

- Source: https://researchdata.bath.ac.uk/1287/
- Type: real grid-tied PV-BESS microgrid.
- Signals: demand, PV generation, battery charging/discharging, and battery SOC.
- Why it fits: explicitly a microgrid dataset with PV and battery storage.
- Use in paper: small-scale real microgrid validation or illustrative
  supplementary case.
- Likely limitation: small scale and limited duration compared with UCSD or
  StoreNet.

## Secondary / Backup Options

### 5. Ausgrid Solar Home Electricity Data

- Source: https://www.ausgrid.com.au/Industry/Our-Research/Data-reports/Solar-home-electricity-data
- Type: rooftop PV prosumer data.
- Signals: residential consumption and rooftop PV generation.
- Why it fits: can construct a virtual community microgrid by aggregating
  multiple PV households.
- Limitation: no battery/storage and not a measured microgrid. Use only as a
  proxy dataset.

### 6. MiRIS Microgrid Dataset

- Source: https://www.kaggle.com/datasets/jonathandumas/miris-microgrid-dataset
- Type: microgrid dataset with high-resolution PV and consumption.
- Why it fits: useful if Kaggle access is available.
- Limitation: Kaggle account/API token may be required, so it is less convenient
  for fully reproducible anonymous review unless the data are mirrored with
  permission.

## Suggested Experimental Design

For a defensible journal submission:

1. Use UCSD Microgrid Database as the main microgrid dataset.
2. Use StoreNet as a distributed/community microgrid case.
3. Use Bath PV-BESS microgrid as a small real microgrid validation case.
4. If OpenCEM downloads cleanly and the target journal accepts recent datasets,
   add it as a second campus/cyber-physical energy dataset.
5. Report results separately by dataset type:
   - real campus microgrid;
   - energy community / community microgrid proxy;
   - small PV-BESS microgrid.

Avoid saying all datasets are "real microgrid datasets" unless the data source
itself supports that wording. Prefer:

- "real campus microgrid dataset" for UCSD;
- "campus energy system / microgrid-scale dataset" for OpenCEM;
- "energy-community dataset used as a community microgrid proxy" for StoreNet;
- "grid-tied PV-BESS microgrid dataset" for Bath.

## Next Implementation Step

After selecting datasets, create one adapter per source that converts raw files
into the experiment CSV schema:

```text
timestamp,power_kw,ghi,dni,dhi,temp_air,load_kw,battery_kw,soc
```

Only `timestamp`, `power_kw`, and enough weather/clear-sky inputs are strictly
required for PV forecasting. `load_kw`, `battery_kw`, and `soc` should be kept
when available because they support the microgrid relevance argument.
