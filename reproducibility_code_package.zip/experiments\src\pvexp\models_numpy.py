from __future__ import annotations

import numpy as np


class PersistenceModel:
    def fit(self, windows):
        return self

    def predict(self, x, meta):
        return meta["last_power"]


class PhysicalReferenceModel:
    def fit(self, windows):
        return self

    def predict(self, x, meta):
        return meta["pref"][:, -1]


class BoundedLinearResidual:
    def __init__(self, *, alpha: float, capacity_kw: float):
        self.alpha = alpha
        self.capacity_kw = capacity_kw
        self.coef_: np.ndarray | None = None

    def fit(self, windows):
        x = self._flatten(windows.x_train)
        y = windows.y_train[:, -1]
        pref = windows.meta_train["pref"][:, -1]
        pmax = windows.meta_train["pmax"][:, -1]
        q_ref = np.clip(pref / (pmax + 1e-6), 1e-4, 1 - 1e-4)
        q_true = np.clip(y / (pmax + 1e-6), 1e-4, 1 - 1e-4)
        residual = self._logit(q_true) - self._logit(q_ref)
        design = np.c_[np.ones(len(x)), x]
        reg = self.alpha * np.eye(design.shape[1])
        reg[0, 0] = 0.0
        self.coef_ = np.linalg.solve(design.T @ design + reg, design.T @ residual)
        return self

    def predict(self, x, meta):
        if self.coef_ is None:
            raise RuntimeError("Model must be fitted before prediction.")
        design = np.c_[np.ones(len(x)), self._flatten(x)]
        delta = design @ self.coef_
        pmax = meta["pmax"][:, -1]
        pref = meta["pref"][:, -1]
        q_ref = np.clip(pref / (pmax + 1e-6), 1e-4, 1 - 1e-4)
        q_hat = 1.0 / (1.0 + np.exp(-(self._logit(q_ref) + delta)))
        return np.clip(pmax * q_hat, 0.0, pmax)

    @staticmethod
    def _flatten(x):
        return x.reshape(x.shape[0], -1)

    @staticmethod
    def _logit(x):
        x = np.clip(x, 1e-6, 1 - 1e-6)
        return np.log(x / (1 - x))


class SklearnModel:
    def __init__(self, *, name: str, seed: int, max_train_samples: int = 5000):
        self.name = name
        self.seed = seed
        self.max_train_samples = max_train_samples
        self.model = None

    def fit(self, windows):
        try:
            if self.name == "svr":
                from sklearn.svm import SVR

                self.model = SVR(C=10.0, epsilon=0.01, gamma="scale")
            elif self.name == "random_forest":
                from sklearn.ensemble import RandomForestRegressor

                self.model = RandomForestRegressor(
                    n_estimators=100,
                    max_depth=16,
                    random_state=self.seed,
                    n_jobs=-1,
                )
            else:
                raise ValueError(self.name)
        except ImportError as exc:
            raise RuntimeError(
                f"Model {self.name} requires scikit-learn. Install experiments/requirements.txt."
            ) from exc
        x_train = windows.x_train.reshape(windows.x_train.shape[0], -1)
        y_train = windows.y_train[:, -1]
        if len(x_train) > self.max_train_samples:
            rng = np.random.default_rng(self.seed)
            idx = rng.choice(len(x_train), size=self.max_train_samples, replace=False)
            x_train = x_train[idx]
            y_train = y_train[idx]
        self.model.fit(x_train, y_train)
        return self

    def predict(self, x, meta):
        if self.model is None:
            raise RuntimeError("Model must be fitted before prediction.")
        return self.model.predict(x.reshape(x.shape[0], -1))
