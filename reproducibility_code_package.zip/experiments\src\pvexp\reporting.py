from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import numpy as np


def write_metrics(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields = sorted({k for row in rows for k in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_summary(rows: list[dict], path: Path) -> None:
    grouped = defaultdict(list)
    for row in rows:
        key = (row["model"], row["horizon"], row["train_fraction"])
        grouped[key].append(row)

    summary = []
    metric_names = [
        "nrmse",
        "nmae",
        "rmse_kw",
        "mae_kw",
        "negative_violation_pct",
        "over_capacity_violation_pct",
    ]
    for (model, horizon, train_fraction), group in grouped.items():
        out = {"model": model, "horizon": horizon, "train_fraction": train_fraction, "n": len(group)}
        for metric in metric_names:
            values = np.array([g[metric] for g in group], dtype=float)
            out[f"{metric}_mean"] = float(values.mean())
            out[f"{metric}_std"] = float(values.std(ddof=1)) if len(values) > 1 else 0.0
        summary.append(out)
    write_metrics(summary, path)
